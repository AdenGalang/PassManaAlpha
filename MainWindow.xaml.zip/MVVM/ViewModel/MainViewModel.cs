﻿using PassManaAlpha.Core;
using PassManaAlpha.Core.Scurity;
using PassManaAlpha.MVVM.Model;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;

namespace PassManaAlpha.MVVM.ViewModel
{
    class MainViewModel : ForkObject
    {
        public ObservableCollection<PasswordEntry> Entries { get; set; } = new();
        public string InputTitle { get; set; }
        public string InputUsername { get; set; }
        public string InputPassword { get; set; }
        public string MasterKey { get; set; } = "deliciouslolis"; //bind this from UI later

        public RelayCommand HomeViewCommand { get; set; }
        public RelayCommand PasswordViewCommand { get; set; }
        public RelayCommand SettingsViewCommand { get; set; }

        public required HomeViewModel HomeVM { get; set; }
        public required PasswordViewModel PasswordVM { get; set; }
        public required SettingsViewModel SettingsVM { get; set; }
        private object _currentView;
        // Commands for saving and loading entries
        
        public object CurrentView
        {
            get { return _currentView; }
            set { _currentView = value;
                OnPropertyChanged();
            }
        }

        public MainViewModel()
        {
            HomeVM = new HomeViewModel();
            PasswordVM = new PasswordViewModel();
            SettingsVM = new SettingsViewModel();

            _currentView = HomeVM;

            HomeViewCommand = new RelayCommand(o =>
            {
                CurrentView = HomeVM;
            });
            PasswordViewCommand = new RelayCommand(o =>
            {
                CurrentView = PasswordVM;
            });
            SettingsViewCommand = new RelayCommand(o =>
            {
                CurrentView = SettingsVM;
            });
            
        }
    }
}
